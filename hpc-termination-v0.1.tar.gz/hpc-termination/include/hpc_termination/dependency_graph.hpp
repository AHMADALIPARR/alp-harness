#pragma once
#include "model.hpp"
#include <vector>

namespace hpc::termination {
DependencyGraph build_dependency_graph(const Program& program);
std::vector<std::vector<std::string>> strongly_connected_components(const DependencyGraph& graph);
bool has_negative_cycle(const DependencyGraph& graph);
}
