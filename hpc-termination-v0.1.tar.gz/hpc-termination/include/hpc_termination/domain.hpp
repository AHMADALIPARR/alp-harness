#pragma once
#include "model.hpp"
#include <cstddef>

namespace hpc::termination {
ActiveDomain compute_active_domain(const Program& program);
std::size_t herbrand_base_bound(const Program& program, const ActiveDomain& domain);
}
