#pragma once
#include "model.hpp"
#include "dependency_graph.hpp"
#include "domain.hpp"
#include "stratification.hpp"
#include "certificate.hpp"
#include <string>

namespace hpc::termination {
TerminationResult certify(const Program& program);
bool rule_can_generate_fresh_terms(const Rule& rule);
bool range_restricted(const Program& program);
}
