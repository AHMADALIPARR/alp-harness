#pragma once
#include "model.hpp"
#include <string>

namespace hpc::termination {
std::string certificate_kind_name(TerminationCertificate::Kind kind);
std::string render_certificate(const TerminationCertificate& certificate);
}
