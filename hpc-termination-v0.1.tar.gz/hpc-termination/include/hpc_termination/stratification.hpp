#pragma once
#include "model.hpp"
#include <vector>

namespace hpc::termination {
std::vector<Stratum> stratify(const Program& program, const DependencyGraph& graph);
}
