# I5 Architecture

```text
Program
  |
  +--> signed dependency graph
  |       |
  |       +--> SCCs
  |       +--> negative-cycle check
  |       +--> stratification
  |
  +--> range restriction
  |
  +--> active domain
  |       |
  |       +--> finite-domain check
  |       +--> Herbrand-base bound
  |
  +--> certificate
          |
          +--> NonRecursive
          +--> Stratified
          +--> Rejected
```

The certificate is an input to the HPC query planner. No downstream backend may convert a rejected or absent certificate into a successful logical result.
